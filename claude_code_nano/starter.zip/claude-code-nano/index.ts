// Claude Code Nano — a minimal Claude Code clone, built to learn how it works.
// The whole agent lives in this one file:
//   1. TOOLS   — 5 plain functions + JSON Schemas describing them to the model
//   2. GATE    — y/n confirmation before destructive tools
//   3. MODEL   — one callModel() hiding the backend
//   4. LOOP    — the agent loop (the whole trick)
//   5. REPL    — a plain readline prompt
// Run: npx tsx index.ts
//
// This is YOUR file — the only editable one in the project. tests/, fixtures/,
// and solution/ are read-only harness. Fill in the stubs marked YOUR CODE HERE,
// problem by problem, until `./ok` is all green. Peek at solution/index.ts only
// after you've tried (it's the spoiler).

import Anthropic from "@anthropic-ai/sdk";
import * as fs from "node:fs";
import * as path from "node:path";
import { spawnSync } from "node:child_process";
import * as readline from "node:readline/promises";
import { pathToFileURL } from "node:url";

// A tiny warm-up used by lecture 01. Fixing this trivial value is Problem 0 —
// the "does my environment run at all?" check.
export function warmup(): number {
  return 61 * 1000 - 1; // Problem 0: something is off by two...
}

// The minimal slice of a readline interface the loop and gate actually use.
// By depending on this instead of a concrete readline.Interface, tests can
// inject a scripted Asker that returns canned answers — no real stdin needed.
export type Asker = { question(prompt: string): Promise<string> };

// ---------------------------------------------------------------------------
// 1. TOOLS
// A "tool" is two things: a JSON Schema that DESCRIBES it to the model, and a
// plain function that RUNS it. The model never executes anything — it only
// asks; runTool() below is where things actually happen on this machine.
//
// A tool is a contract: the schema is the signature the model programs
// against; runTool is the implementation behind it.
//
// The TOOLS schema array is GIVEN — reading a tool contract is the lesson;
// typing out JSON Schema is not. Your job is runTool() below.
// ---------------------------------------------------------------------------

export const TOOLS: Anthropic.Tool[] = [
  {
    name: "read_file",
    description: "Read and return the contents of a file at a relative path.",
    input_schema: {
      type: "object",
      properties: { path: { type: "string", description: "Relative path to the file" } },
      required: ["path"],
    },
  },
  {
    name: "list_files",
    description:
      "List the entries of a directory (one level). Directories end with '/'. Call again on a subdirectory to go deeper.",
    input_schema: {
      type: "object",
      properties: { path: { type: "string", description: "Directory to list; defaults to '.'" } },
      required: [],
    },
  },
  {
    name: "write_file",
    description: "Create or overwrite a file with the given content. Creates parent directories as needed.",
    input_schema: {
      type: "object",
      properties: { path: { type: "string" }, content: { type: "string" } },
      required: ["path", "content"],
    },
  },
  {
    name: "edit_file",
    description:
      "Edit a file by replacing old_string with new_string. old_string must appear EXACTLY once in the file — include surrounding lines to make it unique.",
    input_schema: {
      type: "object",
      properties: {
        path: { type: "string" },
        old_string: { type: "string" },
        new_string: { type: "string" },
      },
      required: ["path", "old_string", "new_string"],
    },
  },
  {
    name: "bash",
    description: "Run a shell command and return its stdout, stderr, and exit code.",
    input_schema: {
      type: "object",
      properties: { command: { type: "string" } },
      required: ["command"],
    },
  },
  // Lecture 07 (bonus): handled inside agentLoop, not runTool — see 07_subagents.md
  {
    name: "task",
    description:
      "Delegate a self-contained subtask to a fresh subagent. The subagent starts with NO shared context — it sees none of this conversation — and returns only its final answer. Put EVERYTHING it needs into the prompt: the goal, any relevant paths, and exactly what to report back.",
    input_schema: {
      type: "object",
      properties: { prompt: { type: "string", description: "The complete, self-contained instructions for the subagent" } },
      required: ["prompt"],
    },
  },
];

// Run one tool call and return the string the model will see as the result.
//   read_file   → file contents (lecture 02)
//   list_files  → one-level dir listing, dirs suffixed "/" (lecture 02)
//   write_file  → create/overwrite, making parent dirs (lecture 03)
//   edit_file   → unique-old_string replacement; throw unless it matches
//                 EXACTLY once (the invariant) (lecture 03)
//   bash        → spawnSync; throw on non-zero exit (lecture 03)
// Failures THROW; the agent loop turns exceptions into is_error tool_results
// so the model can read the error and self-correct.
//
// Lecture 02-03, Problems 1-5.
export function runTool(name: string, input: any): string {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// ---------------------------------------------------------------------------
// 2. PERMISSION GATE
// Tools that change the machine show what they're about to do and wait for a
// y/n. Reads are auto-approved. A denial doesn't crash anything — the loop
// reports it back to the model as an ordinary tool_result.
// ---------------------------------------------------------------------------

export const GATED = new Set(["write_file", "edit_file", "bash"]);

// Render a human-readable summary of what a tool is about to do, so the y/n is
// an informed one:
//   bash       → "$ <command>"
//   write_file → "write <path>:\n<content>"
//   edit_file  → "edit <path>:\n--- old\n<old>\n+++ new\n<new>"
//   anything else → JSON.stringify(input)
//
// Lecture 04.
export function preview(name: string, input: any): string {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// Ask the user to approve a gated action. Print the preview, ask via
// ask.question("Allow? [y/n] "), and return true only for answers that start
// with y/Y (trim + lowercase first). `ask` is any Asker — the real readline
// interface at runtime, a scripted stub in tests.
//
// Lecture 04.
export async function confirm(ask: Asker, name: string, input: any): Promise<boolean> {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// ---------------------------------------------------------------------------
// 3. MODEL
// ALL model I/O goes through this one function. Swap the backend (local
// Ollama, another provider) by changing only what's inside callModel().
// ---------------------------------------------------------------------------

const MODEL = process.env.NANO_MODEL ?? "claude-haiku-4-5-20251001";

const SYSTEM_PROMPT =
  "You are Nano, a minimal coding agent running in the user's terminal. " +
  "Use your tools to explore and modify files under the current working directory. " +
  "Be concise and do exactly what is asked.";

let client: Anthropic | undefined; // created lazily so importing this file never needs an API key

// Send the whole conversation to the model and return its reply. Create the
// Anthropic client lazily (client ??= new Anthropic()) so importing this file
// never requires an API key. Pass model, max_tokens, system (SYSTEM_PROMPT),
// tools (TOOLS), and messages.
//
// Lecture 05.
export async function callModel(messages: Anthropic.MessageParam[]): Promise<Anthropic.Message> {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// ---------------------------------------------------------------------------
// 4. THE AGENT LOOP — the whole trick, and the reason this project exists.
//
//   call the model → it answers with text and/or tool REQUESTS →
//   we run the tools → send the results back → call the model again →
//   ...repeat until it stops asking for tools.
//
// That's it. No planner, no graph, no framework. The intelligence is in the
// model; this loop just gives it hands.
//
// `messages` is the whole conversation state, append-only. Each turn may
// append more work (tool_results the model must react to); the loop ends
// when a turn requests no tools.
//
// `model` is injectable (defaults to the real callModel) so tests can drive the
// loop with scripted fake responses, no API key or network required.
// ---------------------------------------------------------------------------

// Loop: call model(messages); push the assistant reply verbatim; for each
// content block, print text and execute tool_use blocks (gated ones through
// confirm — a denial returns a "declined" string, not an exception; other
// errors become is_error tool_results). Collect tool_results; if none, return.
// Otherwise push them as a { role: "user" } message and loop again.
//
// Lecture 05, the boss level.
export async function agentLoop(
  messages: Anthropic.MessageParam[],
  ask: Asker,
  model: (messages: Anthropic.MessageParam[]) => Promise<Anthropic.Message> = callModel,
): Promise<void> {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// ---------------------------------------------------------------------------
// 5. REPL
// ---------------------------------------------------------------------------

// Readline REPL: read a line at "nano> "; skip blanks; "/exit" quits; push the
// line as a user message and run agentLoop. On error, print it and — if the
// last message is a dangling assistant turn (tool_use with no result) — pop it
// so the next model call isn't rejected.
//
// Lecture 06.
export async function main() {
  // YOUR CODE HERE
  throw new Error("YOUR CODE HERE");
}

// Start the REPL only when run directly — importing this file for smoke
// checks or tests must stay side-effect free.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
