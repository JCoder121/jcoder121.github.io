# Claude Code Nano — starter files

Build your own Claude Code: a working ~350-line agent in TypeScript, problem by
problem, against this read-only test harness. This is the CS61A-style guided
project; the full handout lives at:

    https://jcoder121.github.io/claude_code_nano/

## First run

```
npm install
./ok 00
```

`./ok 00` is expected to **fail** on one test:

```
× Problem 0: warmup() must return 61001 (fix the off-by-two in index.ts)
AssertionError: expected 60999 to be 61001
```

That failure is the shipped, pre-course state — it's **Problem 0** in Lecture 01.
Fixing `warmup()` in `index.ts` so `./ok 00` goes green confirms your toolchain
works, and you're off. Work through the lectures on the course site in order:
six required (01–06, the graded 10 points) plus a bonus lecture 07 (subagents,
+1 → 11/10).

## What's here

- `index.ts` — the one file you edit (typed signatures + `YOUR CODE HERE` stubs).
- `tests/` — the read-only vitest suites, one per lecture (00, 02–07). Run one
  with `./ok 03`; `./ok` runs everything.
- `fixtures/convert.js` — the planted-bug file for Lecture 06's live run.
- `ok` — the tiny test runner (a homage to CS61A's `ok`).

`tests/` and `fixtures/` are read-only harness — only `index.ts` is yours to change.

No API key is needed for any `./ok` run (model calls in the suite are faked, so it
runs offline and free). You only need an `ANTHROPIC_API_KEY` once, for Lecture 06's
live acceptance run (and, optionally, Lecture 07's live subagent run).
