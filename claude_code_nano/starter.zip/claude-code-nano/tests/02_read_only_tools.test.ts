// Lecture 02 — Tools I: Eyes (read_file, list_files).
// A tool is a JSON Schema contract + a plain function. Here we exercise only
// the function half, runTool, for the two read-only tools. All offline.
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { runTool } from "../index.ts";

let dir: string;

beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "nano-02-"));
});
afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

describe("02 · read_file", () => {
  it("returns the exact bytes of the file — read_file is the model's only way to see source", () => {
    const p = path.join(dir, "hello.txt");
    fs.writeFileSync(p, "hello nano");
    expect(runTool("read_file", { path: p })).toBe("hello nano");
  });

  it("throws on a missing file so the loop can hand the error back to the model", () => {
    expect(() => runTool("read_file", { path: path.join(dir, "nope.txt") })).toThrow();
  });
});

describe("02 · list_files", () => {
  it("lists one level, suffixing directories with '/' so the model can tell files from dirs", () => {
    fs.writeFileSync(path.join(dir, "a.txt"), "");
    fs.mkdirSync(path.join(dir, "sub"));
    const out = runTool("list_files", { path: dir }).split("\n").sort();
    expect(out).toEqual(["a.txt", "sub/"]);
  });

  it("defaults to '.' when no path is given — the model may omit optional args", () => {
    // Just assert it returns a string listing without throwing; cwd always has entries.
    const out = runTool("list_files", {});
    expect(typeof out).toBe("string");
    expect(out.length).toBeGreaterThan(0);
  });
});
