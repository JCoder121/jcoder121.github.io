// Lecture 01 — The Shape of an Agent.
// The only runnable check for lecture 01: does your environment work, and did
// you fix the Problem 0 warm-up? These tests import your index.ts — if that
// import throws, nothing else in the course can run.
import { describe, it, expect } from "vitest";
import { warmup } from "../index.ts";

describe("00 · environment sanity", () => {
  it("runs on a modern Node (>= 20) — earlier versions lack the APIs this project uses", () => {
    const major = Number(process.versions.node.split(".")[0]);
    expect(major).toBeGreaterThanOrEqual(20);
  });

  it("imports index.ts without crashing — a broken import blocks every later problem", async () => {
    const mod = await import("../index.ts");
    expect(mod).toBeTruthy();
    expect(typeof mod.warmup).toBe("function");
  });

  it("Problem 0: warmup() must return 61001 (fix the off-by-two in index.ts)", () => {
    // 61 * 1000 + 1 = 61001. The skeleton ships subtracting instead of adding.
    expect(warmup()).toBe(61001);
  });
});
