// Lecture 04 — The Permission Gate.
// First real async code. confirm() takes an Asker (a scripted stub here) so we
// can drive y/n answers with no stdin. A denial is DATA, not an exception.
import { describe, it, expect } from "vitest";
import { preview, confirm, GATED, type Asker } from "../index.ts";

// A scripted Asker: hands back queued answers and records the prompts it saw,
// so we can assert the "[y/n]" question text actually reached the user.
function scriptedAsker(answers: string[]): Asker & { prompts: string[] } {
  const prompts: string[] = [];
  return {
    prompts,
    async question(prompt: string) {
      prompts.push(prompt);
      return answers.shift() ?? "";
    },
  };
}

describe("04 · GATED set", () => {
  it("gates exactly write_file, edit_file, bash — reads auto-approve", () => {
    expect([...GATED].sort()).toEqual(["bash", "edit_file", "write_file"]);
  });
});

describe("04 · preview", () => {
  it("renders a bash command as '$ <command>'", () => {
    expect(preview("bash", { command: "echo hi" })).toBe("$ echo hi");
  });
  it("shows the target path and content for write_file", () => {
    const p = preview("write_file", { path: "a.txt", content: "body" });
    expect(p).toContain("a.txt");
    expect(p).toContain("body");
  });
  it("shows an old/new diff-ish view for edit_file", () => {
    const p = preview("edit_file", { path: "a.txt", old_string: "OLD", new_string: "NEW" });
    expect(p).toContain("OLD");
    expect(p).toContain("NEW");
  });
});

describe("04 · confirm", () => {
  it("shows the '[y/n]' prompt to the user — the gate must actually ask", async () => {
    const ask = scriptedAsker(["y"]);
    await confirm(ask, "bash", { command: "echo hi" });
    expect(ask.prompts.some((p) => p.includes("[y/n]"))).toBe(true);
  });

  it("'y' approves", async () => {
    expect(await confirm(scriptedAsker(["y"]), "bash", { command: "x" })).toBe(true);
  });

  it("'n' denies", async () => {
    expect(await confirm(scriptedAsker(["n"]), "bash", { command: "x" })).toBe(false);
  });

  it("'Y ' (uppercase, trailing space) approves — answers are trimmed and lowercased", async () => {
    expect(await confirm(scriptedAsker(["Y "]), "bash", { command: "x" })).toBe(true);
  });

  it("'yes' approves — any answer starting with y counts", async () => {
    expect(await confirm(scriptedAsker(["yes"]), "bash", { command: "x" })).toBe(true);
  });

  it("'nah' denies — only a leading y approves", async () => {
    expect(await confirm(scriptedAsker(["nah"]), "bash", { command: "x" })).toBe(false);
  });
});
