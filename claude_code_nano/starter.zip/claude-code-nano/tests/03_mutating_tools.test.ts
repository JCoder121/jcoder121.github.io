// Lecture 03 — Tools II: Hands (write_file, edit_file, bash).
// The three destructive tools, plus the edit_file uniqueness INVARIANT — the
// reason an edit can never land in the wrong place.
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { runTool } from "../index.ts";

let dir: string;

beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "nano-03-"));
});
afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

describe("03 · write_file", () => {
  it("creates a file with the given content", () => {
    const p = path.join(dir, "out.txt");
    runTool("write_file", { path: p, content: "abc" });
    expect(fs.readFileSync(p, "utf8")).toBe("abc");
  });

  it("creates missing parent directories so the model needn't mkdir first", () => {
    const p = path.join(dir, "nested/deep/out.txt");
    runTool("write_file", { path: p, content: "x" });
    expect(fs.readFileSync(p, "utf8")).toBe("x");
  });
});

describe("03 · edit_file (the uniqueness invariant)", () => {
  it("replaces a uniquely-matching old_string", () => {
    const p = path.join(dir, "f.txt");
    fs.writeFileSync(p, "one two three");
    runTool("edit_file", { path: p, old_string: "two", new_string: "2" });
    expect(fs.readFileSync(p, "utf8")).toBe("one 2 three");
  });

  it("throws when old_string is not found — no silent no-op edits", () => {
    const p = path.join(dir, "f.txt");
    fs.writeFileSync(p, "hello");
    expect(() => runTool("edit_file", { path: p, old_string: "xyz", new_string: "q" })).toThrow(/not found/);
  });

  it("throws when old_string appears more than once — the invariant that keeps edits unambiguous", () => {
    const p = path.join(dir, "f.txt");
    fs.writeFileSync(p, "aa"); // "a" appears twice
    expect(() => runTool("edit_file", { path: p, old_string: "a", new_string: "b" })).toThrow(/appears 2 times/);
    // File must be untouched when the edit is refused.
    expect(fs.readFileSync(p, "utf8")).toBe("aa");
  });
});

describe("03 · bash", () => {
  it("returns stdout and a zero exit code for a successful command", () => {
    const out = runTool("bash", { command: "echo hi" });
    expect(out).toContain("hi");
    expect(out).toContain("exit code: 0");
  });

  it("throws on a non-zero exit, embedding the exit code so the model sees the failure", () => {
    expect(() => runTool("bash", { command: "exit 3" })).toThrow(/exit code: 3/);
  });
});
