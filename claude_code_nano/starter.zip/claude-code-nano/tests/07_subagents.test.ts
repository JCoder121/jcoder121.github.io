// Lecture 07 (bonus) — Subagents: the task tool. The agent spawns agents.
//
// Same offline discipline as lecture 05: we inject a *scripted model*. The
// twist is that the parent loop and every subagent it spawns share the SAME
// injected model function, so a single response queue drives the whole tree —
// the parent's turns and the subagent's turns interleave in call order. That's
// exactly what lets gates fire inside subagents and keeps every test free.
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { agentLoop, type Asker } from "../index.ts";
import type Anthropic from "@anthropic-ai/sdk";

// --- fake-model + fake-asker plumbing (identical to lecture 05) ------------

// Replays `responses` in order, deep-cloning the messages array on each call
// so we can inspect exactly what each loop — parent OR subagent — was shown.
function scriptedModel(responses: any[]) {
  const seenByCall: Anthropic.MessageParam[][] = [];
  const fn = async (messages: Anthropic.MessageParam[]) => {
    seenByCall.push(structuredClone(messages));
    const next = responses.shift();
    if (!next) throw new Error("scripted model ran out of responses — the loop called it too many times");
    return next as Anthropic.Message;
  };
  return { fn, seenByCall, get callCount() { return seenByCall.length; } };
}

const resp = (content: any[]) => ({ content });
const text = (t: string) => ({ type: "text", text: t });
const toolUse = (id: string, name: string, input: any) => ({ type: "tool_use", id, name, input });

function scriptedAsker(answers: string[]): Asker {
  return { async question() { return answers.shift() ?? ""; } };
}
const noAsker: Asker = { async question() { throw new Error("gate should not have been consulted"); } };

let dir: string;
beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "nano-07-"));
});
afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

// --- (a) -------------------------------------------------------------------

describe("07 · a task tool_use runs a subagent and feeds its answer back", () => {
  it("returns the subagent's final text to the parent as a non-error tool_result", async () => {
    const model = scriptedModel([
      // parent asks for a subagent...
      resp([toolUse("tu_task", "task", { prompt: "figure out the answer" })]),
      // ...the subagent (fresh loop, same model) answers with plain text...
      resp([text("the answer is 42")]),
      // ...and the parent, having received it, wraps up.
      resp([text("my subagent says 42")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "delegate this" }];

    await agentLoop(messages, noAsker, model.fn);

    // parent call 1 (task) + subagent call + parent call 2 (resume) = 3.
    expect(model.callCount).toBe(3);

    const tr = (messages[2] as any).content[0];
    expect(tr.type).toBe("tool_result");
    expect(tr.tool_use_id).toBe("tu_task"); // echoes the request id
    expect(tr.is_error).toBe(false);
    expect(tr.content).toBe("the answer is 42"); // the subagent's LAST assistant text, verbatim
  });
});

// --- (b) -------------------------------------------------------------------

describe("07 · the subagent starts with an EMPTY context — total isolation", () => {
  it("shows the subagent's first call exactly one message: the prompt, none of the parent history", async () => {
    const model = scriptedModel([
      resp([toolUse("tu_task", "task", { prompt: "SELF-CONTAINED INSTRUCTIONS" })]),
      resp([text("done")]),          // subagent
      resp([text("parent wraps up")]), // parent resume
    ]);
    // A parent conversation with real history the subagent must NOT see.
    const messages: Anthropic.MessageParam[] = [
      { role: "user", content: "secret parent request nobody downstream should read" },
    ];

    await agentLoop(messages, noAsker, model.fn);

    // Call 0 is the parent (sees its own history); call 1 is the subagent.
    const subagentFirstSaw = model.seenByCall[1];
    expect(subagentFirstSaw).toHaveLength(1); // EXACTLY one message
    const only = subagentFirstSaw[0] as any;
    expect(only.role).toBe("user");
    expect(only.content).toBe("SELF-CONTAINED INSTRUCTIONS");
    // And crucially, none of the parent's words leaked in.
    expect(JSON.stringify(subagentFirstSaw)).not.toContain("secret parent request");
  });
});

// --- (c) -------------------------------------------------------------------

describe("07 · the subagent can use ordinary tools and runs to completion first", () => {
  it("lets the subagent list_files and finish its whole loop before the parent resumes", async () => {
    fs.writeFileSync(path.join(dir, "beta.txt"), "");
    const model = scriptedModel([
      resp([toolUse("tu_task", "task", { prompt: `list ${dir}` })]),
      // subagent turn 1: a real tool call...
      resp([toolUse("tu_ls", "list_files", { path: dir })]),
      // subagent turn 2: reacts to the listing, then stops.
      resp([text("I found beta.txt")]),
      // parent resume.
      resp([text("subagent explored the dir")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "explore via subagent" }];

    await agentLoop(messages, noAsker, model.fn);

    // parent(1) + subagent ls(1) + subagent text(1) + parent resume(1) = 4.
    expect(model.callCount).toBe(4);
    // The subagent actually saw its own tool_result before finishing: its
    // second call's history includes the list_files result echoing tu_ls.
    const subagentSecondSaw = model.seenByCall[2];
    const fedBack = (subagentSecondSaw[2] as any).content[0];
    expect(fedBack.type).toBe("tool_result");
    expect(fedBack.tool_use_id).toBe("tu_ls");
    expect(fedBack.content).toContain("beta.txt");
    // And the parent got the subagent's completed answer.
    expect((messages[2] as any).content[0].content).toBe("I found beta.txt");
  });
});

// --- (d) -------------------------------------------------------------------

describe("07 · gates still fire INSIDE a subagent, through the same asker", () => {
  it("declines a gated bash call in the subagent and executes nothing", async () => {
    const sentinel = path.join(dir, "SHOULD_NOT_EXIST.txt");
    const model = scriptedModel([
      resp([toolUse("tu_task", "task", { prompt: "try to write a file" })]),
      // subagent asks for a gated bash command...
      resp([toolUse("tu_bash", "bash", { command: `echo pwned > ${sentinel}` })]),
      // ...gets a 'declined' result, then reports back.
      resp([text("I was not allowed to run that")]),
      resp([text("subagent could not do it")]), // parent resume
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "delegate a risky thing" }];

    // ONE shared asker, answering 'n' — proving the subagent consults it.
    await agentLoop(messages, scriptedAsker(["n"]), model.fn);

    // Nothing ran: the side-effect file is absent.
    expect(fs.existsSync(sentinel)).toBe(false);
    // The subagent SAW a declined tool_result (its second call's history).
    const declinedResult = (model.seenByCall[2][2] as any).content[0];
    expect(declinedResult.type).toBe("tool_result");
    expect(String(declinedResult.content).toLowerCase()).toContain("declined");
    expect(declinedResult.is_error).toBe(false);
    // ...and the parent's task result carries the subagent's honest report.
    expect((messages[2] as any).content[0].content).toBe("I was not allowed to run that");
  });
});

// --- (e) -------------------------------------------------------------------

describe("07 · the parent's messages array has the expected round shape", () => {
  it("records assistant(task tool_use) → user(tool_result) → assistant(final text)", async () => {
    const model = scriptedModel([
      resp([toolUse("tu_task", "task", { prompt: "do the thing" })]),
      resp([text("subagent result")]),
      resp([text("all wrapped up")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "kick it off" }];

    await agentLoop(messages, noAsker, model.fn);

    expect(messages.map((m) => m.role)).toEqual(["user", "assistant", "user", "assistant"]);

    const taskUse = (messages[1] as any).content[0];
    expect(taskUse.type).toBe("tool_use");
    expect(taskUse.name).toBe("task");

    const taskResult = (messages[2] as any).content[0];
    expect(taskResult.type).toBe("tool_result");
    expect(taskResult.tool_use_id).toBe("tu_task");

    const finalText = (messages[3] as any).content[0];
    expect(finalText.type).toBe("text");
    expect(finalText.text).toBe("all wrapped up");
  });
});
