// Lecture 05 — The Agent Loop (the whole trick). THE important suite.
//
// We never touch the network. Instead we inject a *scripted model*: a function
// shaped like callModel that returns pre-baked Anthropic.Message objects in
// order. Driving the loop this way lets us assert the exact protocol — how
// tool_use requests turn into tool_result answers, and how the messages array
// grows — deterministically and for free.
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { agentLoop, type Asker } from "../index.ts";
import type Anthropic from "@anthropic-ai/sdk";

// --- fake-model + fake-asker plumbing -------------------------------------

// Build a model that replays `responses` in order, deep-cloning the messages
// array on each call so we can inspect exactly what the model was shown.
function scriptedModel(responses: any[]) {
  const seenByCall: Anthropic.MessageParam[][] = [];
  const fn = async (messages: Anthropic.MessageParam[]) => {
    seenByCall.push(structuredClone(messages));
    const next = responses.shift();
    if (!next) throw new Error("scripted model ran out of responses — the loop called it too many times");
    return next as Anthropic.Message;
  };
  return { fn, seenByCall, get callCount() { return seenByCall.length; } };
}

const resp = (content: any[]) => ({ content });
const text = (t: string) => ({ type: "text", text: t });
const toolUse = (id: string, name: string, input: any) => ({ type: "tool_use", id, name, input });

function scriptedAsker(answers: string[]): Asker {
  return { async question() { return answers.shift() ?? ""; } };
}
const noAsker: Asker = { async question() { throw new Error("gate should not have been consulted"); } };

let dir: string;
beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "nano-05-"));
});
afterEach(() => {
  fs.rmSync(dir, { recursive: true, force: true });
});

// --- (a) -------------------------------------------------------------------

describe("05 · a text-only reply ends the loop", () => {
  it("stops after ONE model call when the reply has no tool_use blocks", async () => {
    const model = scriptedModel([resp([text("all done")])]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "hi" }];

    await agentLoop(messages, noAsker, model.fn);

    expect(model.callCount).toBe(1);
    // user prompt + the assistant's text reply, nothing more.
    expect(messages).toHaveLength(2);
    expect(messages.at(-1)!.role).toBe("assistant");
  });
});

// --- (b) -------------------------------------------------------------------

describe("05 · a tool_use is executed and its result is fed back", () => {
  it("runs list_files, sends back a matching tool_result, and calls the model again", async () => {
    fs.writeFileSync(path.join(dir, "alpha.txt"), "");
    const model = scriptedModel([
      resp([toolUse("tu_1", "list_files", { path: dir })]),
      resp([text("I see alpha.txt")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "list the dir" }];

    await agentLoop(messages, noAsker, model.fn);

    expect(model.callCount).toBe(2);

    // messages: user, assistant(tool_use), user(tool_result), assistant(text)
    expect(messages.map((m) => m.role)).toEqual(["user", "assistant", "user", "assistant"]);
    expect(messages.at(-1)!.role).toBe("assistant"); // ends on the model's final word

    const toolResultMsg = messages[2] as any;
    const tr = toolResultMsg.content[0];
    expect(tr.type).toBe("tool_result");
    // tool_result must echo the tool_use id — that's how the model matches answers to requests.
    expect(tr.tool_use_id).toBe("tu_1");
    expect(tr.is_error).toBe(false);
    expect(tr.content).toContain("alpha.txt");

    // The model's SECOND call must have actually seen that tool_result.
    const secondCallSaw = model.seenByCall[1];
    const fedBack = (secondCallSaw[2] as any).content[0];
    expect(fedBack.tool_use_id).toBe("tu_1");
  });
});

// --- (c) -------------------------------------------------------------------

describe("05 · a failing tool comes back as is_error and the model responds again", () => {
  it("marks read_file on a missing path is_error:true and lets the model self-correct", async () => {
    const missing = path.join(dir, "does-not-exist.txt");
    const model = scriptedModel([
      resp([toolUse("tu_err", "read_file", { path: missing })]),
      resp([text("sorry, that file is missing")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "read it" }];

    await agentLoop(messages, noAsker, model.fn);

    expect(model.callCount).toBe(2); // the model got a second turn to react to the error
    const tr = (messages[2] as any).content[0];
    expect(tr.type).toBe("tool_result");
    expect(tr.is_error).toBe(true); // the failure is DATA the model reads, not a crash
    expect(tr.tool_use_id).toBe("tu_err");
    expect(messages.at(-1)!.role).toBe("assistant");
  });
});

// --- (d) -------------------------------------------------------------------

describe("05 · a denied gated tool does NOT execute", () => {
  it("answering 'n' to a bash call returns a 'declined' result and never runs the command", async () => {
    const sentinel = path.join(dir, "SHOULD_NOT_EXIST.txt");
    const model = scriptedModel([
      resp([toolUse("tu_bash", "bash", { command: `echo pwned > ${sentinel}` })]),
      resp([text("understood, skipping")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "run it" }];

    await agentLoop(messages, scriptedAsker(["n"]), model.fn);

    const tr = (messages[2] as any).content[0];
    expect(tr.type).toBe("tool_result");
    expect(String(tr.content).toLowerCase()).toContain("declined");
    expect(tr.is_error).toBe(false); // a denial is a normal result, not an error
    // Proof the command never ran: its side-effect file is absent.
    expect(fs.existsSync(sentinel)).toBe(false);
  });
});

// --- (e) -------------------------------------------------------------------

describe("05 · messages alternate user/assistant across a two-round conversation", () => {
  it("keeps the assistant-asks / user-answers rhythm the API requires", async () => {
    fs.writeFileSync(path.join(dir, "alpha.txt"), "hello");
    const model = scriptedModel([
      resp([toolUse("t1", "list_files", { path: dir })]),
      resp([toolUse("t2", "read_file", { path: path.join(dir, "alpha.txt") })]),
      resp([text("done")]),
    ]);
    const messages: Anthropic.MessageParam[] = [{ role: "user", content: "explore" }];

    await agentLoop(messages, noAsker, model.fn);

    expect(model.callCount).toBe(3);
    // user, assistant(tool), user(result), assistant(tool), user(result), assistant(text)
    expect(messages.map((m) => m.role)).toEqual([
      "user",
      "assistant",
      "user",
      "assistant",
      "user",
      "assistant",
    ]);
  });
});
