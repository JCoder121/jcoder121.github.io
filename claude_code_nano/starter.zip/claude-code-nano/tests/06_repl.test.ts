// Lecture 06 — The REPL + Endgame.
// main() drives a real readline loop over stdin, so we don't puppet it here.
// What we CAN pin down without a terminal or an API key: main exists, and
// merely importing index.ts is side-effect free — no REPL banner, no Anthropic
// client, no ANTHROPIC_API_KEY required. That side-effect-freedom is exactly
// what makes every other test in this course runnable offline.
import { describe, it, expect, vi } from "vitest";

describe("06 · main()", () => {
  it("exports main as a function", async () => {
    const mod = await import("../index.ts");
    expect(typeof mod.main).toBe("function");
  });

  it("importing index.ts starts no REPL and needs no API key", async () => {
    // If importing had side effects, the module-guard would have printed the
    // 'claude-code-nano — model: ...' banner or constructed a client (which
    // reads ANTHROPIC_API_KEY). We assert neither happened.
    const saved = process.env.ANTHROPIC_API_KEY;
    delete process.env.ANTHROPIC_API_KEY;
    const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    try {
      const mod = await import("../index.ts");
      expect(mod).toBeTruthy();
      const bannerPrinted = logSpy.mock.calls.some((c) => String(c[0]).includes("claude-code-nano"));
      expect(bannerPrinted).toBe(false);
    } finally {
      logSpy.mockRestore();
      if (saved !== undefined) process.env.ANTHROPIC_API_KEY = saved;
    }
  });
});
