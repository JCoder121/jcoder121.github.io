// convert.js — usage: node fixtures/convert.js <celsius>
// Prints the temperature in fahrenheit.
function celsiusToFahrenheit(c) {
  return (c * 5) / 9 + 32; // BUG: should be (c * 9) / 5 + 32
}

console.log(celsiusToFahrenheit(Number(process.argv[2])));
